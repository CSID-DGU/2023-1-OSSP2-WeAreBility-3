from namuwikitext import fetch_all

fetch_all()
