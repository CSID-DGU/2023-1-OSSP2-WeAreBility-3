__author__ = 'lovit'
__name__ = 'Namuwikitext'
__license__ = "CC BY-NC-SA 2.0 KR \nReference: https://creativecommons.org/licenses/by-nc-sa/2.0/kr/"
__version__ = '0.3.0'

